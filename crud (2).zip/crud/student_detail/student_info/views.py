from django.shortcuts import render,redirect,get_object_or_404
from .forms import studentform
from .models import student

def student_list(request):
    context = {"student_list":student.objects.all()}
     
    return render(request,"student_list.html",context)

def student_form(request,id=0):
    instance = None
    if request.method == "GET":
        if id:
            instance = get_object_or_404(student, pk=id)
        form = studentform(instance=instance)
        return render(request, "student_form.html", {"form": form})
    else:
        if id:
            instance = get_object_or_404(student, pk=id)
        form = studentform(request.POST, instance=instance)
        if form.is_valid():
            form.save()
        return redirect("studentlist")
def student_delete(request,id):
       students = student.objects.get(pk=id)
      
    #    if request.method == "POST":
       students.delete()
       return redirect("studentlist")
       
    
    