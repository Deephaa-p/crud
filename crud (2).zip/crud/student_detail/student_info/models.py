from django.db import models
class  standard(models.Model):
    grade = models.CharField(max_length=5)

    def __str__(self):
        return self.grade
# Create your models here.
class student(models.Model):
    name = models.CharField(max_length=30)
    student_id = models.CharField(max_length=10)
    mobile = models.CharField(max_length=10)
    standard = models.ForeignKey(standard, on_delete=models.CASCADE)